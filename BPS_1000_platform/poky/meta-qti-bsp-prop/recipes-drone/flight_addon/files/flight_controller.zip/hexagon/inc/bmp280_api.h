/*==============================================================================
 Copyright (c) 2015 Qualcomm Technologies, Inc.
 All rights reserved. Qualcomm Proprietary and Confidential.
 ==============================================================================*/

#ifndef BMP280_API_H_
#define BMP280_API_H_

#include <stdbool.h>

#define BMP280_SLAVE_ADDRESS 0b1110110       /* 7-bit slave address */
#define BMP280_BUS_FREQUENCY_IN_KHZ 400
#define BMP280_TRANSFER_TIMEOUT_IN_USECS 9000

typedef int32_t  BMP280_S32_t;
typedef int64_t  BMP280_S64_t;
typedef uint32_t BMP280_U32_t;

struct bmp280_sensor_data
{
   BMP280_S32_t t_fine;
   uint32_t pressure_in_pa;
   float temperature_in_c;
   uint32_t sensor_read_counter;
   uint64_t last_read_time_in_usecs;
   uint64_t error_count;
};

/**
 * Retrieves a detailed error code for the last bmp280 function executed.
 * This is typically called after a general error of -1 is returned by the
 * bmp280 function.
 * @param handle
 * Handle returned from a previous call to to bmp280_open().
 * @return
 * 0 for success
 * -1 for failure
 */
int bmp280_get_last_error(uint32_t handle);

/**
 * Sets the pressure at sea level for the location of the sensor.  This is used
 * internally to convert pressure to altitude.
 * @note
 * TODO: This function is currently not implemented.
 * @param handle
 * @param altimeter_setting_in_mbars
 * @return
 * 0 for success
 * -1 for failure
 */
int bmp280_set_altimeter(uint32_t handle, float altimeter_setting_in_mbars);

/**
 * Opens access to the pressure sensor on the I2C bus specified by the device
 * path parameter.
 * @param i2c_device_path
 * Device path for the I2C bus used by the pressure sensor, e.g.: /dev/iic-4
 * @return
 * 0 for success
 * -1 for failure
 */
int bmp280_open(const char *i2c_device_path,uint32_t* handle);

/**
 * Close the connection to the bus used by this sensor, and release any
 * associated resources.
 * @param handle
 */
void bmp280_close(uint32_t handle);

/**
 * Read the pressure sensor data from the from the previously opened sensor connection.
 * @param handle
 * Handle used identify the pressure sensor previously opened with the bmp280_open() function.
 * @param out_data
 * Reference to the structure that will be filled with pressure sensor data.
 * @param is_new_data_required
 * - true: The caller will block until new sensor data is retrieved in the next sensor polling interval.
 * - false: Retrieves the last sensor value generated and cached by the driver.
 * @return
 * 0 for success
 * -1 for failure
 */
int bmp280_get_sensor_data(uint32_t handle, struct bmp280_sensor_data *out_data, bool is_new_data_required);

#endif /* BMP280_API_H_ */
