/*==============================================================================
 Copyright (c) 2015 Qualcomm Technologies, Inc.
 All rights reserved. Qualcomm Proprietary and Confidential.
 ==============================================================================*/

#ifndef UART_ESC_H_
#define UART_ESC_H_

#include <stdint.h>

/* Forward declaration */
class EscCmdPacket;
#ifdef ATL_QXDM_PERF
struct flight_perf;
#endif

/**
 * All supported ESC models.
 */
enum esc_model_t {
   ESC_200MM = 0,
   ESC_350MM,
   ESC_210QC,
   NUM_ESC_MODEL,
};

/**
 * UartEsc is the class defining all the behaviors of a UART ESC
 * device, including ESC model, UART device path, baud rate,
 * sending RPM/PWM commands and receiving feedback information from ESC.
 * One UartEsc instance controls all ESCs and motors. The EscCmdPacket and
 * EscFbPacketParser instance handles the communication with all ESCs.
 *
 * Different UART ESC devices runs with different messaging protocols. Thus
 * the proper EscCmdPacket subclass and EscFbPacketParser subclass is
 * instantiated for given ESC model.
 */
class UartEsc
{
public:
   static UartEsc* get_instance();

   /**
    * UartEsc constructor
    * This does nothing but creates a new instance. See initialize() for
    * the actual intiialization work that needs to be done before operating
    * the ESCs.
    */
   UartEsc();

   /**
    * UartEsc destructor
    * If this UartEsc instance has been initialized, this destructor closes
    * the UART device connected to ESC.
    */
   ~UartEsc();

   /**
    * Initialize the UART ESC device.
    * This initialier opens and initializes the UART device. This must be
    * called before conducting any other operations. On successful return from
    * this function, the UartEsc instance is ready to send PWM/RPM commands
    * and receive feedback packets.
    *
    * @param esc_model  ESC model in enum esc_model_t type
    * @param uart_dev   path to the UART device which the ESCs are connected to
    * @param baud_rate   UART baud rate in bps
    * @return  0 on success, -1 on error
    */
   int initialize(enum esc_model_t esc_model, const char* uart_dev, int baud_rate);

   /**
    * Set RPM values on ESC. For the ESC models which support LED control, this
    * function would turn off all LEDs.
    *
    * @param[in] rpms     array of rpm values to set on ESC
    * @param[in] num_esc  number of ESCs. The caller must ensuare num_esc
    *                     does not exceed the rpms array size.
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int send_rpms(int16_t *rpms, int num_esc);

   /**
    * Set RPM value on each ESC. Set LED status on the airframe.
    * LED on airframe is only supported on 200MM. Calling this function
    * on other models has the same effect as send_rpms().
    *
    * @param[in] rpms     array of rpm values to set on ESC
    * @param[in] num_esc  number of ESCs. The caller must ensuare num_esc
    *                     does not exceed the rpms array size.
    * @param[in] ledRed   flag to turn on/off red led
    * @param[in] ledGrn   flag to turn on/off green led
    * @param[in] ledBlu   flag to turn on/off blue led
    * @param[in] ledArm   flag to turn on/off arm led
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int send_rpms_leds(int16_t *rpms, int num_esc,
                      uint8_t ledRed, uint8_t ledGrn,
                      uint8_t ledBlu, uint8_t ledArm);

   /**
    * Set RPM value and LED status on each ESC. This feature is NOT available
    * in 200MM and 350MM. Calling this function on 200MM and 350MM has the same
    * effect as send_rpms().
    *
    * @param[in] rpms     array of rpm values to set on ESC
    * @param[in] leds     array of LED status to set on ESC. LED value is an
    *                     8 bit value, and the bit 0 to 2 represents red, green
    *                     and blue, respectively.
    * @param[in] num_esc  number of ESCs. The caller must ensuare num_esc
    *                     does not exceed the rpms and leds array size.
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int send_rpms_leds(int16_t *rpms, uint8_t *leds, int num_esc);

   /**
    * Set PWM values on ESC. On ESC models which support LED control, this
    * function would keep LEDs off.
    *
    * @param[in] pwms     array of pwm values to set on each ESC
    * @param[in] num_esc  number of ESCs. The caller must ensuare num_esc
    *                     does not exceed the pwms array size.
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int send_pwms(int16_t *pwms, int num_esc);

   /**
    * Set PWM value on each ESC. Set LED status on the airframe.
    * LED on airframe is only supported on 200MM. Calling this function
    * on other models has the same effect as send_pwms().
    *
    * @param[in] pwms     array of pwm values to set on ESC
    * @param[in] num_esc  number of ESCs. The caller must ensuare num_esc
    *                     does not exceed the pwms array size.
    * @param[in] ledRed   flag to turn on/off red led
    * @param[in] ledGrn   flag to turn on/off green led
    * @param[in] ledBlu   flag to turn on/off blue led
    * @param[in] ledArm   flag to turn on/off arm led
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int send_pwms_leds(int16_t *pwms, int num_esc,
                      uint8_t ledRed, uint8_t ledGrn,
                      uint8_t ledBlu, uint8_t ledArm);

   /**
    * Set PWM value and LED status on each ESC. This feature is NOT available
    * in 200MM and 350MM. Calling this function on 200MM and 350MM has the same
    * effect as send_pwms().
    *
    * @param[in] pwms     array of pwm values to set on each ESC
    * @param[in] leds     array of LED status to set on ESC. LED value is an
    *                     8 bit value, and the bit 0 to 2 represents red, green
    *                     and blue, respectively.
    * @param[in] num_esc  number of ESCs. The caller must ensuare num_esc
    *                     does not exceed the pwms and leds array size.
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int send_pwms_leds(int16_t *pwms, uint8_t *leds, int num_esc);

   /**
    * Send tone command to all ESC's. For the ESC models which support tone
    * command on specific ESC, e.g. 210QC, this function sends tone command to
    * all ESC's.
    *
    * @param[in] frequency  tone frequency 0 - 255
    * @param[in] duration   duration, value range 0 - 255. 50 is approximate 1 sec.
    * @param[in] power      tone amplitude, value range 0 - 100
    * @return 0 on success, -1 on error or if uninitialized
    */
   int send_tone(uint8_t frequency, uint8_t duration, uint8_t power);

   /**
    * Send tone command to specified ESC's. Note that sending tone to specified
    * ESC is not supported on 200MM and 350MM. Calling this function on 200MM
    * and 350MM has the same effect as send_tone()
    *
    * @param[in] frequency  tone frequency 0 - 255
    * @param[in] duration   duration, value range 0 - 255. 50 is approximate 1 sec.
    * @param[in] power      tone amplitude, value range 0 - 100
    * @param[in] mask       bit mask indicating the ESC which the tone command is
    *                       sent to. Bit x represents ESC ID x. Use 0xFF to
    *                       send tone command to all ESC's
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int send_tone_with_mask(uint8_t frequency, uint8_t duration, uint8_t power,
                           uint8_t mask);

   /**
    * Reset the ESC with the specified ID. ESC ID is 0 based. For the ESC models
    * which do not support ESC resetting, this function has no effect.
    *
    * @param[in] esc_id
    * ID of the ESC to reset.  esc_id value is between 0 and num_esc - 1
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int reset_esc(uint8_t esc_id);

   /**
    * Getter for maximum RPM supported by this ESC
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int16_t max_rpm();

   /**
    * Getter for minimum RPM supported by this ESC
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int16_t min_rpm();

   /**
    * Getter for maximum PWM supported by this ESC
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int16_t max_pwm();

   /**
    * Getter for minimum PWM supported by this ESC
    *
    * @return 0 on success, -1 on error or if uninitialized
    */
   int16_t min_pwm();

   bool is_initialized() { return is_initialized_; }

private:

   /**
    * Send command packet to serial device
    *
    * @return 0 on success, -1 on error
    */
   int send_command(char* packet, int packet_size);

   static UartEsc* instance_;

   bool is_initialized_;

   enum esc_model_t esc_model_;

   int uart_dev_fd_;

   const char* uart_dev_;

   EscCmdPacket* cmd_packet_;

#ifdef ATL_QXDM_PERF
   struct flight_perf uartesc_perf_;
#endif
};


#endif /* UART_ESC_H_ */
