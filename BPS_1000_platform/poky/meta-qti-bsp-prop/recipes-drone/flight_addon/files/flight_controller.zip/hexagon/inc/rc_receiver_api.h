/*==============================================================================
 Copyright (c) 2015 Qualcomm Technologies, Inc.
 All rights reserved. Qualcomm Proprietary and Confidential.
 ==============================================================================*/

#ifndef RC_RECEIVER_API_H_
#define RC_RECEIVER_API_H_

/**
 * The types of receiver modules that this driver supports.
 */
enum RC_RECEIVER_TYPES
{
   RC_RECEIVER_TYPE_UNKNOWN,//!< that the type of the receiver is unknown
   RC_RECEIVER_SPEKTRUM,    //!< receiver from Spektrum, using the DSM2 and DSMX protocol
   RC_RECEIVER_LEMONRX,     //!< receiver from LemonRX
};

/**
 * The maximum number of receiver manufacturers supported by this driver.
 */
#define RC_RECEIVER_TYPES_MAX_NUM 2

/**
 * The maximum number of receiver channels supported by this driver.
 * TODO-JYW: Provide support for Spektrum receivers with more than 8 channels.
 */
#define RC_RECEIVER_MAX_NUM_RECEIVER_CHANNELS 8

/**
 * The error codes describing the overall driver state after a function
 * is called that indicates a failure.  The values are retrieved with the
 * rc_receiver_get_last_error() function.
 */
enum RC_RECEIVER_ERRORS
{
   RC_RECEIVER_ERROR_SUCCESS = 0,                //!< no errors detected
   RC_RECEIVER_ERROR_PACKET_TIMEOUT = -32,       //!< timed out waiting for a receiver packet, okay to try again
   RC_RECEIVER_ERROR_PACKET_NOT_READY,           //!< packet not fully received
   RC_RECEIVER_ERROR_PACKET_ERROR,               //!< error in the format of the packet
   RC_RECEIVER_ERROR_PROTOCL_ERROR,              //!< error in the packet protocol
   RC_RECEIVER_ERROR_RECEIVER_TYPE_UNRECOGNIZED, //!< the receiver type specified is unknown
   RC_RECEIVER_ERROR_RECEIVER_ALREADY_OPENED,    //!< the rc_receiver driver has already been opened at the specified device path
   RC_RECEIVER_ERROR_INVALID_PARAMETER,          //!< the rc_receiver driver function was called with an invalid parameter
   RC_RECEIVER_ERROR_NO_MEMORY,                  //!< memory allocation failure
   RC_RECEIVER_ERROR_FATAL,                      //!< an unspecified error occurred
};

/**
 * The maximum duration of time to wait for an incoming receiver packet before
 * returning to the caller with an error.
 */
#define RC_RECEIVER_MAX_WAIT_NEW_PACKET_IN_MSECS 1000

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * This function should be called to initialize the receiver driver and prepare communication
 * with receiver connected to the device named by the device_path parameter.
 * @param type
 * The manufacturer of the receiver supported.
 * @param device_path
 * The device path indicating the bus or port for the receiver module connection.
 * @return
 * > 0: The handle associated with this instance of the driver.
 * 0: An error code occurred.  Call rc_receiver_get_last_error() for more details.
 *
 */
uint32_t rc_receiver_open(enum RC_RECEIVER_TYPES type, const char *device_path);

/**
 * Returns the last complete receiver packet received by the driver, containing the values
 * for each of the channels in use.  This function will block for a specified timeout, until
 * a complete packet is received.
 * @param handle
 * The handle returned from the rc_receiver_open function.
 * @param out_channel_values
 * Pointer to an array allocated by the caller. The value of the channels provided by the receiver
 * will be copied into this array.  The values returned are in ascending channel order,
 * e.g. out_channel_value[0] contains the current value of transmitter channel 1, out_channel_value[1] channel 2,
 * and so on.
 * @param in_out_num_channels
 * Upon entry this parameter should contain the maximum number of channel values that can be copied
 * into the out_channel_values array.  This value must be provided by the caller.
 * Upon return this parameter will contain the number of entries copied by the function into the
 * out_channel_values array. An error will be returned if the size of the array (number of channels)
 * is too small to contain the number of received channels.
 * @return
 * - 0 successfully retrieved a packet of receiver data, returned in the out_channel_values parameter
 * - -1 failed to retrieve the packet of receiver data.  Call rc_receiver_get_last_error for a more
 * detailed error indication
 */
int rc_receiver_get_packet(uint32_t handle, uint16_t *out_channel_values, uint32_t *in_out_num_channels);

/**
 * The value of error code for the last function called in this driver.  After the function is called
 * the error code is cleared internally (indicating success).  A success code may also be returned if
 * the last function was called successfully.
 * @param handle
 * The handle returned from the rc_receiver_open function.
 * @return
 * - 0: Success
 * - -EINVAL: Invalid parameter.
 * - -ENOMEM: Insufficient memory to complete the requested operation (e.g. array too small to receive
 *            channel values).
 */
enum RC_RECEIVER_ERRORS rc_receiver_get_last_error(uint32_t handle);

/**
 * Closes access to the receiver previously opened and frees internal resources allocated with the
 * rc_receiver_open function.
 * @param handle
 */
void rc_receiver_close(uint32_t handle);

#ifdef __cplusplus
}
#endif

#endif /* RC_RECEIVER_API_H_ */
